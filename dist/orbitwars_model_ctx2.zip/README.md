# Orbit Wars Agent — "ctx2" (current model)

This package contains our submitted agent and the full pipeline that produced it.
Everything needed to describe the model for the report is here.

Leaderboard: public score ~1067 (single converged value; the cluster drifts ±30).

---

## 1. What the agent is (one paragraph)

A **hybrid agent**. A rule-based game engine handles all the mechanics — generating
candidate moves, sizing fleets, aiming at moving (orbiting) targets, avoiding the sun,
resolving combat, and reinforcing threatened planets. The single highest-leverage
decision — **which planet to attack from where** — is made by a **learned neural
network** (a re-ranker) trained by **imitation learning**. The engine proposes candidate
captures; the network scores and re-orders them; the engine executes the top picks.

Design rationale: the *mechanical* parts of the game are easy to express as reliable
rules, while *target selection* is the hard, judgment-heavy decision worth learning. So
we learn only that, on top of a solid engine.

---

## 2. The per-turn decision pipeline

1. **Parse observation** → planets (owner, ships, production, orbital position), fleets,
   ownership totals, in-flight threats.
2. **Generate candidates.** For each owned planet, list reachable capturable targets,
   pre-ordered by a cheap heuristic. Each candidate's position in that list = `idx`.
3. **Featurize** each candidate into a **46-dim vector** (see §4).
4. **Score** with the neural network → one scalar per candidate.
5. **Re-rank**: `priority = idx − bonus · sigmoid(score)` (bonus ≈ 1.45 in 2-player,
   1.25 in 4-player). A high learned score promotes a candidate up the list; `bonus`
   controls how much the network may override the heuristic order. Sort, keep top-K.
6. **Execute.** The engine commits fleets to the chosen targets — fleet size (win + hold),
   aim/lead, sun-avoidance — and runs its reinforcement pass.

---

## 3. The neural network (our model) — architecture

- **Input: 230 features per candidate.** The 46 base features (§4), **plus** the
  element-wise **mean, max, min, and standard deviation of those 46 features across all
  candidates in the same turn** (46 × 4 = 184 context features).
  - This is a **DeepSet-style permutation-invariant set encoding**: it lets the network
    judge a target *relative to the other options available this turn*, not in isolation —
    a cheap approximation of cross-candidate attention.
- **Network: MLP `230 → 128 → 128 → 1`, ReLU.** Output = a scalar quality score.
- Exported to **pure Python** (`model/student_weights_{2p,4p}.py`, functions `score_many`)
  so it runs inside the competition's 1-second-per-turn budget with large margin
  (~0.1 s/turn). Separate networks for 2-player and 4-player games.

## 4. The 46 base features

- **Global board state** (shared across candidates that turn): game progress (turn/500),
  players alive, our share of planets / production / ships, our growth "momentum", gap to
  the current leader, whether we're being targeted, and short-horizon **trend** features
  (enemy aggression trend, enemy attack rhythm, rate enemies are closing in, board
  convergence).
- **Per-candidate move features**: source planet ships & production, target production,
  arrival ETA, whether we can win the capture (`margin`, `can_win`), threat arriving
  *after* we capture vs. friendly support, target ROI (production per ship), economic
  impact, whether the target is the weakest enemy, etc.

Full ordered list: `engine/feature46_manifest.json` and the `FEATURE_NAMES` list at the
top of `model/student_weights_*.py`.

## 5. How it was trained (the ML method)

- **Imitation learning / knowledge distillation.** We collected a dataset of
  `(features → expert target-score)` pairs by recording a strong reference policy across
  ~250 games (2p + 4p), grouped per decision so set-context can be computed.
  Dataset size: ~25k (2p) + ~37k (4p) candidate-sets, ~510k labeled candidates.
- **Objective: supervised regression (MSE)** to reproduce the expert's scores. GPU,
  ~1 min. It is **offline supervised learning** — no reward, no exploration.
- **Fidelity (held-out):** the network's top pick matches the expert's ~85% of the time
  (top-3 ~95%); R² ≈ 0.93.
- **Inductive bias note:** the set-pooling makes the model **order-agnostic and
  permutation-invariant** over a variable number of candidates.

## 6. Honest findings (good material for the report's discussion)

- **Imitation has a ceiling: you cannot beat your teacher by copying it.** Higher
  imitation fidelity did **not** monotonically improve play (a richer-fidelity variant
  scored *lower*), illustrating that fidelity ≠ performance and that surpassing the
  expert requires **outcome-based RL**, not better cloning.
- **Distribution shift / compounding errors** (the classic behavioral-cloning weakness):
  at test time the agent visits its *own* state distribution, not the expert's; small
  errors compound. The principled fix is **DAgger** (iteratively re-label the agent's own
  states) — a clear "future work" point.
- **Evaluation is treacherous:** local self-play / pool win-rates were poor predictors of
  ladder rank (distribution shift to the ladder population; TrueSkill score drift of
  ±30). Only paired, held-out evaluation and the live ladder are trustworthy.

---

## File manifest

```
agent/
  submission_distilled_ctx2.py   Self-contained competition submission (single file).
                                 Bundles the engine + feature module + our network.
model/
  student_weights_2p.py          OUR trained network (2-player), pure Python.
  student_weights_4p.py          OUR trained network (4-player), pure Python.
                                 MEAN/STD = input normalization; W0..W2/B0..B2 = MLP
                                 weights; score_many(rows) = forward pass incl. set pooling.
training/
  distill_collect_grouped.py     Collect (features -> expert scores) grouped per decision.
  distill_train_ctx.py           Train the network; report held-out top-1; export pure Python.
  validate_student.py            Measure per-candidate-set top-1 agreement vs the teacher.
  selfplay.py                    Self-play A/B harness (swap network weights into the engine).
  build_distilled_submission.py  Bundle engine+features+network into the single submission file.
  distilled.py                   Loader that plugs our network into the engine in-process.
engine/
  orbit_base.py                  Rule-based game engine (parsing, geometry, fleet sizing,
                                 aiming, combat resolution, reinforcement).
  main.py                        Candidate generation, the 46-feature extractor, and the
                                 re-rank glue (steps 2-5 above).
  feature46_manifest.json        Feature schema + re-rank hyperparameters (bonus, expand).
```

(Training data — ~85 MB of `.npz` — is omitted here; regenerate with
`distill_collect_grouped.py` if needed.)
